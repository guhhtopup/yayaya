import { useState, useEffect, useRef } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { ArrowLeft, Wallet } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function Deposit() {
  const { user, refreshProfile } = useAuth();
  const navigate = useNavigate();
  const [amount, setAmount] = useState('');
  const [loading, setLoading] = useState(false);
  const [depositData, setDepositData] = useState<any>(null);
  const [timeLeft, setTimeLeft] = useState(0);
  const intervalRef = useRef<NodeJS.Timeout>();

  const quickAmounts = [2000, 5000, 10000, 20000, 50000, 100000];

  const handleDeposit = async () => {
    const num = parseInt(amount);
    if (!num || num < 2000) { toast.error('Minimal deposit Rp2.000'); return; }
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('proxy-deposit', {
        body: { action: 'create', amount: num },
      });
      if (error) throw error;
      if (!data?.success) throw new Error(data?.message || 'Gagal membuat deposit');

      setDepositData(data.data);

      // Save transaction
      await supabase.from('transactions').insert({
        user_id: user!.id,
        type: 'deposit',
        status: 'pending',
        amount: num,
        external_id: data.data.id,
        details: data.data,
      });

      // Calculate time left
      const expiry = data.data.expired_at_ts;
      setTimeLeft(Math.max(0, Math.floor((expiry - Date.now()) / 1000)));
      toast.success('QRIS berhasil dibuat!');
    } catch (err: any) {
      toast.error(err.message || 'Gagal membuat deposit');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!depositData) return;
    intervalRef.current = setInterval(async () => {
      setTimeLeft((t) => {
        if (t <= 1) {
          clearInterval(intervalRef.current);
          return 0;
        }
        return t - 1;
      });
      // Check status every 10 seconds
      try {
        const { data } = await supabase.functions.invoke('proxy-deposit', {
          body: { action: 'status', deposit_id: depositData.id },
        });
        if (data?.data?.status === 'success') {
          clearInterval(intervalRef.current);
          toast.success('Pembayaran berhasil!');
          await supabase.from('transactions').update({ status: 'success' }).eq('external_id', depositData.id);
          await refreshProfile();
          setDepositData(null);
        }
      } catch {}
    }, 10000);
    return () => clearInterval(intervalRef.current);
  }, [depositData]);

  const handleCancel = async () => {
    if (!depositData) return;
    try {
      await supabase.functions.invoke('proxy-deposit', {
        body: { action: 'cancel', deposit_id: depositData.id },
      });
      await supabase.from('transactions').update({ status: 'cancelled' }).eq('external_id', depositData.id);
      setDepositData(null);
      toast.info('Deposit dibatalkan');
    } catch {}
  };

  const formatTime = (s: number) => `${Math.floor(s / 60)}:${(s % 60).toString().padStart(2, '0')}`;

  return (
    <div className="mx-auto max-w-lg px-4 py-6 space-y-4">
      <button onClick={() => navigate(-1)} className="flex items-center gap-2 text-sm text-muted-foreground">
        <ArrowLeft className="h-4 w-4" /> Kembali
      </button>
      <h1 className="text-xl font-bold flex items-center gap-2"><Wallet className="h-5 w-5 text-primary" /> Deposit</h1>

      {!depositData ? (
        <Card>
          <CardHeader><CardTitle className="text-base">Masukkan Nominal</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <Input type="number" placeholder="Minimal Rp2.000" value={amount} onChange={(e) => setAmount(e.target.value)} min={2000} />
            <div className="grid grid-cols-3 gap-2">
              {quickAmounts.map((q) => (
                <Button key={q} variant={amount === q.toString() ? 'default' : 'outline'} size="sm" onClick={() => setAmount(q.toString())}>
                  Rp{q.toLocaleString('id-ID')}
                </Button>
              ))}
            </div>
            <Button className="w-full" onClick={handleDeposit} disabled={loading}>
              {loading ? 'Memproses...' : 'Buat QRIS'}
            </Button>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="p-5 space-y-4 text-center">
            <p className="text-sm text-muted-foreground">Scan QRIS untuk membayar</p>
            <p className="text-2xl font-bold text-primary">Rp{depositData.total?.toLocaleString('id-ID')}</p>
            {depositData.qr_image && (
              <img src={depositData.qr_image} alt="QRIS" className="mx-auto h-56 w-56 rounded-lg" />
            )}
            {timeLeft > 0 && (
              <p className="text-sm text-muted-foreground">Expired dalam: <span className="font-bold text-primary">{formatTime(timeLeft)}</span></p>
            )}
            {timeLeft <= 0 && <p className="text-sm text-destructive font-medium">QRIS telah expired</p>}
            <div className="flex gap-2">
              <Button variant="outline" className="flex-1" onClick={handleCancel}>Batalkan</Button>
              <Button className="flex-1" onClick={() => { setDepositData(null); setAmount(''); }}>Deposit Baru</Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
