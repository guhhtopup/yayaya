import { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { supabase } from '@/integrations/supabase/client';
import { Bot, Send, User } from 'lucide-react';

interface Message {
  role: 'user' | 'assistant';
  content: string;
}

export default function AiChat() {
  const [messages, setMessages] = useState<Message[]>([
    { role: 'assistant', content: 'Halo! Saya AI Kaze Shop. Ada yang bisa saya bantu? 😊' },
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const sendMessage = async () => {
    if (!input.trim() || loading) return;
    const userMsg = input.trim();
    setInput('');
    setMessages((prev) => [...prev, { role: 'user', content: userMsg }]);
    setLoading(true);
    try {
      const { data } = await supabase.functions.invoke('proxy-ai', { body: { text: userMsg } });
      const reply = data?.result || data?.answer || data?.data?.result || 'Maaf, saya tidak bisa menjawab saat ini.';
      setMessages((prev) => [...prev, { role: 'assistant', content: reply }]);
    } catch {
      setMessages((prev) => [...prev, { role: 'assistant', content: 'Maaf, terjadi kesalahan. Coba lagi nanti.' }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="mx-auto flex h-[calc(100vh-4.5rem)] max-w-lg flex-col">
      <div className="border-b p-4">
        <h1 className="text-lg font-bold flex items-center gap-2"><Bot className="h-5 w-5 text-primary" /> AI Kaze Shop</h1>
        <p className="text-xs text-muted-foreground">Tanya apapun tentang layanan kami</p>
      </div>
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {messages.map((msg, i) => (
          <div key={i} className={`flex gap-2 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            {msg.role === 'assistant' && (
              <div className="flex h-7 w-7 flex-shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground">
                <Bot className="h-4 w-4" />
              </div>
            )}
            <Card className={`max-w-[80%] p-3 text-sm ${msg.role === 'user' ? 'bg-primary text-primary-foreground border-0' : ''}`}>
              {msg.content}
            </Card>
            {msg.role === 'user' && (
              <div className="flex h-7 w-7 flex-shrink-0 items-center justify-center rounded-full bg-muted">
                <User className="h-4 w-4" />
              </div>
            )}
          </div>
        ))}
        {loading && (
          <div className="flex gap-2">
            <div className="flex h-7 w-7 items-center justify-center rounded-full bg-primary text-primary-foreground"><Bot className="h-4 w-4" /></div>
            <Card className="p-3 text-sm"><span className="animate-pulse">Mengetik...</span></Card>
          </div>
        )}
        <div ref={bottomRef} />
      </div>
      <div className="border-t p-4 flex gap-2">
        <Input placeholder="Ketik pesan..." value={input} onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && sendMessage()} />
        <Button onClick={sendMessage} disabled={loading} size="icon"><Send className="h-4 w-4" /></Button>
      </div>
    </div>
  );
}
