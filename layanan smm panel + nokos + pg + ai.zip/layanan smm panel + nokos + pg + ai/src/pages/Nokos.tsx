import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { ArrowLeft, Phone, Copy, RefreshCw } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function Nokos() {
  const { user, refreshProfile } = useAuth();
  const navigate = useNavigate();
  const [selectedService, setSelectedService] = useState('');
  const [selectedCountry, setSelectedCountry] = useState<any>(null);
  const [selectedProvider, setSelectedProvider] = useState('');
  const [selectedOperator, setSelectedOperator] = useState('');
  const [orderData, setOrderData] = useState<any>(null);
  const [otpStatus, setOtpStatus] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  const { data: services } = useQuery({
    queryKey: ['nokos-services'],
    queryFn: async () => {
      const { data } = await supabase.functions.invoke('proxy-nokos', { body: { action: 'services' } });
      return data?.data || [];
    },
  });

  const { data: countries } = useQuery({
    queryKey: ['nokos-countries', selectedService],
    queryFn: async () => {
      if (!selectedService) return [];
      const { data } = await supabase.functions.invoke('proxy-nokos', { body: { action: 'countries', service_id: selectedService } });
      return data?.data || [];
    },
    enabled: !!selectedService,
  });

  const { data: operators } = useQuery({
    queryKey: ['nokos-operators', selectedCountry?.name, selectedProvider],
    queryFn: async () => {
      if (!selectedCountry || !selectedProvider) return [];
      const { data } = await supabase.functions.invoke('proxy-nokos', { body: { action: 'operators', country: selectedCountry.name, provider_id: selectedProvider } });
      return data?.data || [];
    },
    enabled: !!selectedCountry && !!selectedProvider,
  });

  const handleOrder = async () => {
    if (!selectedCountry || !selectedProvider || !selectedOperator) { toast.error('Lengkapi semua pilihan'); return; }
    setLoading(true);
    try {
      const { data } = await supabase.functions.invoke('proxy-nokos', {
        body: { action: 'order', number_id: selectedCountry.number_id, provider_id: selectedProvider, operator_id: selectedOperator },
      });
      if (data?.success) {
        setOrderData(data.data);
        await supabase.from('transactions').insert({
          user_id: user!.id, type: 'nokos', status: 'waiting', amount: data.data.price,
          external_id: data.data.order_id, details: data.data,
        });
        await refreshProfile();
        toast.success('Nomor berhasil dipesan!');
      } else {
        toast.error(data?.message || 'Gagal memesan nomor');
      }
    } catch (err: any) {
      toast.error(err.message || 'Gagal memesan');
    } finally { setLoading(false); }
  };

  const checkOtp = async () => {
    if (!orderData?.order_id) return;
    try {
      const { data } = await supabase.functions.invoke('proxy-nokos', {
        body: { action: 'get_status', order_id: orderData.order_id },
      });
      setOtpStatus(data?.data);
      if (data?.data?.otp_code && data.data.otp_code !== '-') {
        toast.success('OTP diterima!');
      }
    } catch {}
  };

  return (
    <div className="mx-auto max-w-lg px-4 py-6 space-y-4">
      <button onClick={() => navigate(-1)} className="flex items-center gap-2 text-sm text-muted-foreground">
        <ArrowLeft className="h-4 w-4" /> Kembali
      </button>
      <h1 className="text-xl font-bold flex items-center gap-2"><Phone className="h-5 w-5 text-primary" /> Nomor Virtual (Nokos)</h1>

      {!orderData ? (
        <Card>
          <CardHeader><CardTitle className="text-base">Pesan Nomor</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Aplikasi</Label>
              <Select value={selectedService} onValueChange={(v) => { setSelectedService(v); setSelectedCountry(null); }}>
                <SelectTrigger><SelectValue placeholder="Pilih aplikasi" /></SelectTrigger>
                <SelectContent>
                  {services?.map((s: any) => (
                    <SelectItem key={s.service_code} value={s.service_code.toString()}>{s.service_name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            {countries && countries.length > 0 && (
              <div className="space-y-2">
                <Label>Negara</Label>
                <Select onValueChange={(v) => {
                  const c = countries.find((x: any) => x.number_id?.toString() === v);
                  setSelectedCountry(c);
                  if (c?.pricelist?.[0]) setSelectedProvider(c.pricelist[0].provider_id);
                }}>
                  <SelectTrigger><SelectValue placeholder="Pilih negara" /></SelectTrigger>
                  <SelectContent>
                    {countries.map((c: any) => (
                      <SelectItem key={c.number_id} value={c.number_id?.toString()}>
                        {c.name} - {c.pricelist?.[0]?.price_format || `Rp${c.pricelist?.[0]?.price}`} ({c.stock_total} stok)
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
            {operators && operators.length > 0 && (
              <div className="space-y-2">
                <Label>Operator</Label>
                <Select value={selectedOperator} onValueChange={setSelectedOperator}>
                  <SelectTrigger><SelectValue placeholder="Pilih operator" /></SelectTrigger>
                  <SelectContent>
                    {operators.map((o: any) => (
                      <SelectItem key={o.id} value={o.id.toString()}>{o.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
            <Button className="w-full" onClick={handleOrder} disabled={loading}>
              {loading ? 'Memproses...' : 'Pesan Nomor'}
            </Button>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="p-5 space-y-4 text-center">
            <p className="text-sm text-muted-foreground">Nomor Anda</p>
            <p className="text-2xl font-bold font-mono">{orderData.phone_number}</p>
            <Button variant="outline" size="sm" onClick={() => { navigator.clipboard.writeText(orderData.phone_number); toast.success('Disalin!'); }}>
              <Copy className="mr-1 h-3 w-3" /> Salin
            </Button>
            <p className="text-sm">{orderData.service} • {orderData.country}</p>
            {otpStatus?.otp_code && otpStatus.otp_code !== '-' ? (
              <div className="rounded-lg bg-accent p-4">
                <p className="text-sm text-muted-foreground">Kode OTP</p>
                <p className="text-3xl font-bold text-primary">{otpStatus.otp_code}</p>
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">Menunggu SMS...</p>
            )}
            <div className="flex gap-2">
              <Button variant="outline" className="flex-1" onClick={checkOtp}>
                <RefreshCw className="mr-1 h-3 w-3" /> Cek OTP
              </Button>
              <Button className="flex-1" onClick={() => { setOrderData(null); setOtpStatus(null); }}>
                Pesan Baru
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
