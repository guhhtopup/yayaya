import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import { ArrowLeft, ShoppingCart } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function SmmPanel() {
  const { user, refreshProfile } = useAuth();
  const navigate = useNavigate();
  const [selectedCategory, setSelectedCategory] = useState('');
  const [selectedService, setSelectedService] = useState('');
  const [link, setLink] = useState('');
  const [quantity, setQuantity] = useState('');
  const [ordering, setOrdering] = useState(false);

  const { data: services, isLoading } = useQuery({
    queryKey: ['smm-services'],
    queryFn: async () => {
      const { data, error } = await supabase.functions.invoke('proxy-smm', {
        body: { action: 'services' },
      });
      if (error) throw error;
      return data || [];
    },
  });

  const categories = services ? [...new Set(services.map((s: any) => s.category))] : [];
  const filteredServices = services?.filter((s: any) => !selectedCategory || s.category === selectedCategory) || [];
  const currentService = services?.find((s: any) => s.service?.toString() === selectedService);

  const handleOrder = async () => {
    if (!selectedService || !link || !quantity) { toast.error('Lengkapi semua field'); return; }
    const qty = parseInt(quantity);
    if (!currentService || qty < currentService.min || qty > currentService.max) {
      toast.error(`Quantity harus antara ${currentService?.min} - ${currentService?.max}`);
      return;
    }
    setOrdering(true);
    try {
      const { data, error } = await supabase.functions.invoke('proxy-smm', {
        body: { action: 'add', service: selectedService, link, quantity: qty },
      });
      if (error) throw error;
      if (data?.order) {
        await supabase.from('transactions').insert({
          user_id: user!.id,
          type: 'smm',
          status: 'processing',
          amount: Math.ceil(parseFloat(currentService.rate) * qty),
          external_id: data.order.toString(),
          details: { service: currentService.name, link, quantity: qty },
        });
        await refreshProfile();
        toast.success(`Order #${data.order} berhasil dibuat!`);
        setLink(''); setQuantity('');
      } else {
        toast.error(data?.error || 'Gagal membuat order');
      }
    } catch (err: any) {
      toast.error(err.message || 'Gagal membuat order');
    } finally {
      setOrdering(false);
    }
  };

  return (
    <div className="mx-auto max-w-lg px-4 py-6 space-y-4">
      <button onClick={() => navigate(-1)} className="flex items-center gap-2 text-sm text-muted-foreground">
        <ArrowLeft className="h-4 w-4" /> Kembali
      </button>
      <h1 className="text-xl font-bold flex items-center gap-2"><ShoppingCart className="h-5 w-5 text-primary" /> SMM Panel</h1>

      <Card>
        <CardHeader><CardTitle className="text-base">Buat Order</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          {isLoading ? (
            <p className="text-sm text-muted-foreground">Memuat layanan...</p>
          ) : (
            <>
              <div className="space-y-2">
                <Label>Kategori</Label>
                <Select value={selectedCategory} onValueChange={(v) => { setSelectedCategory(v); setSelectedService(''); }}>
                  <SelectTrigger><SelectValue placeholder="Pilih kategori" /></SelectTrigger>
                  <SelectContent>
                    {categories.map((c: string) => (<SelectItem key={c} value={c}>{c}</SelectItem>))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Layanan</Label>
                <Select value={selectedService} onValueChange={setSelectedService}>
                  <SelectTrigger><SelectValue placeholder="Pilih layanan" /></SelectTrigger>
                  <SelectContent>
                    {filteredServices.map((s: any) => (
                      <SelectItem key={s.service} value={s.service.toString()}>
                        {s.name} - Rp{parseFloat(s.rate).toLocaleString('id-ID')}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              {currentService && (
                <p className="text-xs text-muted-foreground">Min: {currentService.min} | Max: {currentService.max} | Harga/1000: Rp{parseFloat(currentService.rate).toLocaleString('id-ID')}</p>
              )}
              <div className="space-y-2">
                <Label>Link</Label>
                <Input placeholder="https://..." value={link} onChange={(e) => setLink(e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Quantity</Label>
                <Input type="number" placeholder="Jumlah" value={quantity} onChange={(e) => setQuantity(e.target.value)} />
              </div>
              {currentService && quantity && (
                <p className="text-sm font-medium">Total: Rp{Math.ceil(parseFloat(currentService.rate) * parseInt(quantity || '0') / 1000).toLocaleString('id-ID')}</p>
              )}
              <Button className="w-full" onClick={handleOrder} disabled={ordering}>
                {ordering ? 'Memproses...' : 'Order Sekarang'}
              </Button>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
