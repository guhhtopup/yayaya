import { useAuth } from '@/contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Wallet, ShoppingCart, Phone, Newspaper, Tv, Ticket } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

const services = [
  { icon: ShoppingCart, label: 'SMM Panel', path: '/smm', color: 'bg-primary/10 text-primary' },
  { icon: Phone, label: 'Nokos', path: '/nokos', color: 'bg-green-100 text-green-700' },
  { icon: Newspaper, label: 'Berita', path: '/berita', color: 'bg-blue-100 text-blue-700' },
  { icon: Tv, label: 'Anime', path: '/anime', color: 'bg-purple-100 text-purple-700' },
  { icon: Ticket, label: 'Ticket', path: '/ticket', color: 'bg-orange-100 text-orange-700' },
  { icon: Wallet, label: 'Deposit', path: '/deposit', color: 'bg-emerald-100 text-emerald-700' },
];

export default function Index() {
  const { user, profile } = useAuth();
  const navigate = useNavigate();

  const { data: announcements } = useQuery({
    queryKey: ['announcements'],
    queryFn: async () => {
      const { data } = await supabase.from('announcements').select('*').order('created_at', { ascending: false }).limit(3);
      return data || [];
    },
  });

  if (!user) {
    navigate('/login');
    return null;
  }

  return (
    <div className="mx-auto max-w-lg px-4 py-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-muted-foreground">Selamat datang,</p>
          <h1 className="text-xl font-bold">{profile?.name || 'User'} 👋</h1>
        </div>
        <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary text-primary-foreground font-bold text-lg">
          {(profile?.name || 'U')[0].toUpperCase()}
        </div>
      </div>

      {/* Balance Card */}
      <Card className="bg-gradient-to-br from-primary to-primary/80 text-primary-foreground border-0 shadow-lg">
        <CardContent className="p-5">
          <p className="text-sm opacity-80">Saldo Anda</p>
          <p className="text-3xl font-bold mt-1">Rp{(profile?.balance || 0).toLocaleString('id-ID')}</p>
          <div className="mt-4 flex gap-2">
            <Button size="sm" variant="secondary" onClick={() => navigate('/deposit')} className="bg-white/20 text-white hover:bg-white/30 border-0">
              <Wallet className="mr-1 h-4 w-4" /> Deposit
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Services Grid */}
      <div>
        <h2 className="text-lg font-semibold mb-3">Layanan</h2>
        <div className="grid grid-cols-3 gap-3">
          {services.map((s) => (
            <button key={s.path} onClick={() => navigate(s.path)} className="flex flex-col items-center gap-2 rounded-xl border bg-card p-4 transition-all hover:shadow-md active:scale-95">
              <div className={`flex h-10 w-10 items-center justify-center rounded-xl ${s.color}`}>
                <s.icon className="h-5 w-5" />
              </div>
              <span className="text-xs font-medium">{s.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Announcements */}
      {announcements && announcements.length > 0 && (
        <div>
          <h2 className="text-lg font-semibold mb-3">Informasi Terbaru</h2>
          <div className="space-y-2">
            {announcements.map((a) => (
              <Card key={a.id} className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => navigate('/informasi')}>
                <CardContent className="p-4">
                  <p className="font-medium text-sm">{a.title}</p>
                  <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{a.content}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
