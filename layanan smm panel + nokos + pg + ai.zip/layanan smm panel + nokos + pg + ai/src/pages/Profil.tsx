import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { UserCircle, Shield, LogOut, Wallet, Crown } from 'lucide-react';

export default function Profil() {
  const { user, profile, signOut } = useAuth();
  const navigate = useNavigate();
  const [showAdmin, setShowAdmin] = useState(false);
  const [adminEmail, setAdminEmail] = useState('');
  const [adminPass, setAdminPass] = useState('');
  const [checking, setChecking] = useState(false);

  const handleAdminLogin = async () => {
    setChecking(true);
    try {
      // Validate admin credentials server-side
      const { data, error } = await supabase.functions.invoke('proxy-admin', {
        body: { action: 'validate', email: adminEmail, password: adminPass },
      });
      if (error) throw error;
      if (data?.valid) {
        sessionStorage.setItem('kaze_admin', 'true');
        toast.success('Berhasil masuk Admin Panel!');
        setShowAdmin(false);
        navigate('/admin');
      } else {
        toast.error('Email atau password admin salah');
      }
    } catch {
      toast.error('Gagal validasi admin');
    } finally {
      setChecking(false);
    }
  };

  const handleLogout = async () => {
    await signOut();
    navigate('/login');
  };

  return (
    <div className="mx-auto max-w-lg px-4 py-6 space-y-4">
      <h1 className="text-xl font-bold flex items-center gap-2"><UserCircle className="h-5 w-5 text-primary" /> Profil</h1>

      <Card>
        <CardContent className="p-5 space-y-3">
          <div className="flex items-center gap-4">
            <div className="flex h-14 w-14 items-center justify-center rounded-full bg-primary text-primary-foreground text-xl font-bold">
              {(profile?.name || 'U')[0].toUpperCase()}
            </div>
            <div>
              <p className="font-semibold">{profile?.name || 'User'}</p>
              <p className="text-sm text-muted-foreground">{user?.email}</p>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3 pt-2">
            <div className="rounded-lg bg-accent p-3 text-center">
              <Wallet className="mx-auto h-5 w-5 text-primary mb-1" />
              <p className="text-xs text-muted-foreground">Saldo</p>
              <p className="text-sm font-bold">Rp{(profile?.balance || 0).toLocaleString('id-ID')}</p>
            </div>
            <div className="rounded-lg bg-accent p-3 text-center">
              <Crown className="mx-auto h-5 w-5 text-primary mb-1" />
              <p className="text-xs text-muted-foreground">Plan</p>
              <p className="text-sm font-bold capitalize">{profile?.plan || 'free'}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="space-y-2">
        <Button variant="outline" className="w-full justify-start" onClick={() => navigate('/ticket')}>
          <Shield className="mr-2 h-4 w-4" /> Buat Ticket
        </Button>
        <Button variant="outline" className="w-full justify-start" onClick={() => setShowAdmin(true)}>
          <Shield className="mr-2 h-4 w-4 text-primary" /> Admin Panel
        </Button>
        <Button variant="destructive" className="w-full" onClick={handleLogout}>
          <LogOut className="mr-2 h-4 w-4" /> Logout
        </Button>
      </div>

      <Dialog open={showAdmin} onOpenChange={setShowAdmin}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Admin Panel</DialogTitle>
            <DialogDescription>Masukkan kredensial admin</DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div className="space-y-2">
              <Label>Email Admin</Label>
              <Input type="email" value={adminEmail} onChange={(e) => setAdminEmail(e.target.value)} placeholder="admin@example.com" />
            </div>
            <div className="space-y-2">
              <Label>Password</Label>
              <Input type="password" value={adminPass} onChange={(e) => setAdminPass(e.target.value)} placeholder="••••••••" />
            </div>
            <Button className="w-full" onClick={handleAdminLogin} disabled={checking}>
              {checking ? 'Memverifikasi...' : 'Masuk'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
