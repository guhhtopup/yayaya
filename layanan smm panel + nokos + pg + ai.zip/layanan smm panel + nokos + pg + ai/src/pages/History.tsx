import { useAuth } from '@/contexts/AuthContext';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Skeleton } from '@/components/ui/skeleton';
import { Clock } from 'lucide-react';

const statusColor: Record<string, string> = {
  success: 'bg-green-100 text-green-700',
  pending: 'bg-yellow-100 text-yellow-700',
  processing: 'bg-blue-100 text-blue-700',
  cancelled: 'bg-red-100 text-red-700',
  failed: 'bg-red-100 text-red-700',
  waiting: 'bg-yellow-100 text-yellow-700',
};

export default function History() {
  const { user } = useAuth();

  const { data: transactions, isLoading } = useQuery({
    queryKey: ['transactions', user?.id],
    queryFn: async () => {
      const { data } = await supabase.from('transactions').select('*').eq('user_id', user!.id).order('created_at', { ascending: false });
      return data || [];
    },
    enabled: !!user,
  });

  const filterByType = (type: string) => transactions?.filter((t) => type === 'all' || t.type === type) || [];

  const renderList = (items: typeof transactions) => {
    if (!items || items.length === 0) return <p className="text-center text-sm text-muted-foreground py-8">Belum ada transaksi</p>;
    return items.map((t) => (
      <Card key={t.id} className="mb-2">
        <CardContent className="p-3 flex items-center justify-between">
          <div>
            <p className="text-sm font-medium capitalize">{t.type}</p>
            <p className="text-xs text-muted-foreground">{new Date(t.created_at).toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' })}</p>
            {t.external_id && <p className="text-xs text-muted-foreground">#{t.external_id}</p>}
          </div>
          <div className="text-right">
            <p className="text-sm font-semibold">Rp{t.amount.toLocaleString('id-ID')}</p>
            <Badge variant="secondary" className={statusColor[t.status] || ''}>{t.status}</Badge>
          </div>
        </CardContent>
      </Card>
    ));
  };

  return (
    <div className="mx-auto max-w-lg px-4 py-6 space-y-4">
      <h1 className="text-xl font-bold flex items-center gap-2"><Clock className="h-5 w-5 text-primary" /> Riwayat Transaksi</h1>
      {isLoading ? (
        <div className="space-y-2">{[1, 2, 3].map((i) => (<Skeleton key={i} className="h-16 w-full rounded-xl" />))}</div>
      ) : (
        <Tabs defaultValue="all">
          <TabsList className="w-full">
            <TabsTrigger value="all" className="flex-1">Semua</TabsTrigger>
            <TabsTrigger value="deposit" className="flex-1">Deposit</TabsTrigger>
            <TabsTrigger value="smm" className="flex-1">SMM</TabsTrigger>
            <TabsTrigger value="nokos" className="flex-1">Nokos</TabsTrigger>
          </TabsList>
          <TabsContent value="all">{renderList(filterByType('all'))}</TabsContent>
          <TabsContent value="deposit">{renderList(filterByType('deposit'))}</TabsContent>
          <TabsContent value="smm">{renderList(filterByType('smm'))}</TabsContent>
          <TabsContent value="nokos">{renderList(filterByType('nokos'))}</TabsContent>
        </Tabs>
      )}
    </div>
  );
}
