import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Info } from 'lucide-react';

export default function Informasi() {
  const { data: announcements, isLoading } = useQuery({
    queryKey: ['announcements'],
    queryFn: async () => {
      const { data } = await supabase.from('announcements').select('*').order('created_at', { ascending: false });
      return data || [];
    },
  });

  return (
    <div className="mx-auto max-w-lg px-4 py-6 space-y-4">
      <h1 className="text-xl font-bold flex items-center gap-2"><Info className="h-5 w-5 text-primary" /> Informasi</h1>
      {isLoading ? (
        <div className="space-y-3">{[1, 2, 3].map((i) => (<Skeleton key={i} className="h-20 w-full rounded-xl" />))}</div>
      ) : announcements && announcements.length > 0 ? (
        <div className="space-y-3">
          {announcements.map((a) => (
            <Card key={a.id}>
              <CardContent className="p-4 space-y-2">
                <p className="font-semibold">{a.title}</p>
                <p className="text-sm text-muted-foreground whitespace-pre-wrap">{a.content}</p>
                {a.media_url && a.media_type === 'image' && (
                  <img src={a.media_url} alt="" className="rounded-lg w-full max-h-60 object-cover" />
                )}
                {a.media_url && a.media_type === 'video' && (
                  <video src={a.media_url} controls className="rounded-lg w-full max-h-60" />
                )}
                <p className="text-xs text-muted-foreground">{new Date(a.created_at).toLocaleDateString('id-ID', { day: '2-digit', month: 'long', year: 'numeric' })}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <p className="text-center text-sm text-muted-foreground py-8">Belum ada informasi</p>
      )}
    </div>
  );
}
