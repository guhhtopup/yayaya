import { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { adminApi } from '@/lib/adminApi';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { toast } from 'sonner';
import { Plus, Trash2, Edit } from 'lucide-react';

export default function AdminInformasi() {
  const queryClient = useQueryClient();
  const [showForm, setShowForm] = useState(false);
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [mediaUrl, setMediaUrl] = useState('');
  const [mediaType, setMediaType] = useState('');
  const [editId, setEditId] = useState<string | null>(null);

  const { data: announcements } = useQuery({
    queryKey: ['admin-announcements'],
    queryFn: () => adminApi.getAnnouncements(),
  });

  const handleSave = async () => {
    if (!title.trim() || !content.trim()) { toast.error('Judul dan konten wajib diisi'); return; }
    const payload = {
      title: title.trim(),
      content: content.trim(),
      media_url: mediaUrl || null,
      media_type: mediaType || null,
    };
    if (editId) {
      await adminApi.updateAnnouncement(editId, payload);
      toast.success('Informasi diperbarui');
    } else {
      await adminApi.insertAnnouncement(payload);
      toast.success('Informasi ditambahkan');
    }
    resetForm();
    queryClient.invalidateQueries({ queryKey: ['admin-announcements'] });
  };

  const handleDelete = async (id: string) => {
    await adminApi.deleteAnnouncement(id);
    toast.success('Informasi dihapus');
    queryClient.invalidateQueries({ queryKey: ['admin-announcements'] });
  };

  const handleEdit = (a: any) => {
    setEditId(a.id); setTitle(a.title); setContent(a.content);
    setMediaUrl(a.media_url || ''); setMediaType(a.media_type || '');
    setShowForm(true);
  };

  const resetForm = () => {
    setShowForm(false); setEditId(null); setTitle(''); setContent(''); setMediaUrl(''); setMediaType('');
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Kelola Informasi</h1>
        <Button onClick={() => { resetForm(); setShowForm(true); }}><Plus className="mr-1 h-4 w-4" /> Tambah</Button>
      </div>

      <div className="space-y-3">
        {announcements?.map((a: any) => (
          <Card key={a.id}>
            <CardContent className="p-4 flex justify-between items-start">
              <div className="flex-1">
                <p className="font-semibold">{a.title}</p>
                <p className="text-sm text-muted-foreground line-clamp-2 mt-1">{a.content}</p>
                <p className="text-xs text-muted-foreground mt-1">{new Date(a.created_at).toLocaleDateString('id-ID')}</p>
              </div>
              <div className="flex gap-1 ml-2">
                <Button size="sm" variant="ghost" onClick={() => handleEdit(a)}><Edit className="h-4 w-4" /></Button>
                <Button size="sm" variant="ghost" onClick={() => handleDelete(a.id)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
              </div>
            </CardContent>
          </Card>
        ))}
        {(!announcements || announcements.length === 0) && <p className="text-center text-muted-foreground py-8">Belum ada informasi</p>}
      </div>

      <Dialog open={showForm} onOpenChange={setShowForm}>
        <DialogContent>
          <DialogHeader><DialogTitle>{editId ? 'Edit' : 'Tambah'} Informasi</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div className="space-y-2"><Label>Judul</Label><Input value={title} onChange={(e) => setTitle(e.target.value)} /></div>
            <div className="space-y-2"><Label>Konten</Label><Textarea value={content} onChange={(e) => setContent(e.target.value)} rows={4} /></div>
            <div className="space-y-2"><Label>Media URL (opsional)</Label><Input value={mediaUrl} onChange={(e) => setMediaUrl(e.target.value)} placeholder="https://..." /></div>
            <div className="space-y-2">
              <Label>Tipe Media</Label>
              <Select value={mediaType} onValueChange={setMediaType}>
                <SelectTrigger><SelectValue placeholder="Pilih tipe" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="image">Gambar</SelectItem>
                  <SelectItem value="video">Video</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button className="w-full" onClick={handleSave}>Simpan</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
