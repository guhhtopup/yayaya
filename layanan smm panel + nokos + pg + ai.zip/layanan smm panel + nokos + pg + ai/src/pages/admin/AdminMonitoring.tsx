import { useQuery } from '@tanstack/react-query';
import { adminApi } from '@/lib/adminApi';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

export default function AdminMonitoring() {
  const { data: transactions } = useQuery({
    queryKey: ['admin-monitoring'],
    queryFn: () => adminApi.getTransactions(50),
    refetchInterval: 10000,
  });

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">Monitoring Transaksi</h1>
      <Card>
        <CardHeader><CardTitle className="text-base">Real-time Transactions</CardTitle></CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-2 px-2">ID</th>
                  <th className="text-left py-2 px-2">Type</th>
                  <th className="text-left py-2 px-2">Amount</th>
                  <th className="text-left py-2 px-2">Status</th>
                  <th className="text-left py-2 px-2">Waktu</th>
                </tr>
              </thead>
              <tbody>
                {transactions?.map((t: any) => (
                  <tr key={t.id} className="border-b last:border-0">
                    <td className="py-2 px-2 font-mono text-xs">{t.external_id || t.id.slice(0, 8)}</td>
                    <td className="py-2 px-2 capitalize">{t.type}</td>
                    <td className="py-2 px-2">Rp{t.amount.toLocaleString('id-ID')}</td>
                    <td className="py-2 px-2">
                      <Badge variant="secondary" className={
                        t.status === 'success' ? 'bg-green-100 text-green-700' :
                        t.status === 'pending' ? 'bg-yellow-100 text-yellow-700' : 'bg-red-100 text-red-700'
                      }>{t.status}</Badge>
                    </td>
                    <td className="py-2 px-2 text-xs text-muted-foreground">{new Date(t.created_at).toLocaleString('id-ID')}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            {(!transactions || transactions.length === 0) && <p className="text-center text-muted-foreground py-8">Belum ada transaksi</p>}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
