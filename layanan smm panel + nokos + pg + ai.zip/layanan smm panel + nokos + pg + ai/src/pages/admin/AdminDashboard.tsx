import { useQuery } from '@tanstack/react-query';
import { adminApi } from '@/lib/adminApi';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { DollarSign, Users, ShoppingCart, TrendingUp } from 'lucide-react';

export default function AdminDashboard() {
  const { data: profiles } = useQuery({
    queryKey: ['admin-profiles'],
    queryFn: () => adminApi.getProfiles(),
  });

  const { data: transactions } = useQuery({
    queryKey: ['admin-transactions'],
    queryFn: () => adminApi.getTransactions(),
  });

  const totalUsers = profiles?.length || 0;
  const totalOmset = transactions?.filter((t: any) => t.status === 'success' && t.type === 'deposit').reduce((sum: number, t: any) => sum + t.amount, 0) || 0;
  const totalOrders = transactions?.filter((t: any) => t.type !== 'deposit').length || 0;
  const pendingDeposits = transactions?.filter((t: any) => t.type === 'deposit' && t.status === 'pending').length || 0;

  const stats = [
    { label: 'Total Omset', value: `Rp${totalOmset.toLocaleString('id-ID')}`, icon: DollarSign, color: 'text-green-600 bg-green-100' },
    { label: 'Total Users', value: totalUsers, icon: Users, color: 'text-blue-600 bg-blue-100' },
    { label: 'Total Orders', value: totalOrders, icon: ShoppingCart, color: 'text-purple-600 bg-purple-100' },
    { label: 'Pending Deposits', value: pendingDeposits, icon: TrendingUp, color: 'text-orange-600 bg-orange-100' },
  ];

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Dashboard</h1>
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((s) => (
          <Card key={s.label}>
            <CardContent className="p-5 flex items-center gap-4">
              <div className={`flex h-12 w-12 items-center justify-center rounded-xl ${s.color}`}>
                <s.icon className="h-6 w-6" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">{s.label}</p>
                <p className="text-xl font-bold">{s.value}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader><CardTitle className="text-base">Transaksi Terbaru</CardTitle></CardHeader>
        <CardContent>
          <div className="space-y-2">
            {transactions?.slice(0, 10).map((t: any) => (
              <div key={t.id} className="flex items-center justify-between border-b pb-2 last:border-0">
                <div>
                  <p className="text-sm font-medium capitalize">{t.type}</p>
                  <p className="text-xs text-muted-foreground">{new Date(t.created_at).toLocaleString('id-ID')}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-semibold">Rp{t.amount.toLocaleString('id-ID')}</p>
                  <p className={`text-xs ${t.status === 'success' ? 'text-green-600' : t.status === 'pending' ? 'text-yellow-600' : 'text-red-600'}`}>{t.status}</p>
                </div>
              </div>
            ))}
            {(!transactions || transactions.length === 0) && <p className="text-sm text-muted-foreground text-center py-4">Belum ada transaksi</p>}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
