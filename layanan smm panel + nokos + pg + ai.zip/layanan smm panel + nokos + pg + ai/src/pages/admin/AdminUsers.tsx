import { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { adminApi } from '@/lib/adminApi';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import { Ban, CheckCircle, Wallet, Crown } from 'lucide-react';

export default function AdminUsers() {
  const queryClient = useQueryClient();
  const [search, setSearch] = useState('');
  const [selectedUser, setSelectedUser] = useState<any>(null);
  const [balanceChange, setBalanceChange] = useState('');
  const [newPlan, setNewPlan] = useState('');
  const [dialogType, setDialogType] = useState<'balance' | 'plan' | null>(null);

  const { data: users } = useQuery({
    queryKey: ['admin-users'],
    queryFn: () => adminApi.getProfiles(),
  });

  const filtered = users?.filter((u: any) =>
    u.name?.toLowerCase().includes(search.toLowerCase()) ||
    u.email?.toLowerCase().includes(search.toLowerCase())
  ) || [];

  const toggleBan = async (userId: string, currentBan: boolean) => {
    await adminApi.updateProfile(userId, { is_banned: !currentBan });
    toast.success(currentBan ? 'User di-unbanned' : 'User di-banned');
    queryClient.invalidateQueries({ queryKey: ['admin-users'] });
  };

  const handleBalanceChange = async (add: boolean) => {
    if (!selectedUser || !balanceChange) return;
    const amount = parseInt(balanceChange);
    if (isNaN(amount) || amount <= 0) { toast.error('Nominal tidak valid'); return; }
    const newBalance = add ? selectedUser.balance + amount : Math.max(0, selectedUser.balance - amount);
    await adminApi.updateProfile(selectedUser.user_id, { balance: newBalance });
    toast.success(`Saldo ${add ? 'ditambahkan' : 'dikurangi'}`);
    setDialogType(null); setBalanceChange('');
    queryClient.invalidateQueries({ queryKey: ['admin-users'] });
  };

  const handlePlanChange = async () => {
    if (!selectedUser || !newPlan) return;
    await adminApi.updateProfile(selectedUser.user_id, { plan: newPlan });
    toast.success('Plan diubah');
    setDialogType(null); setNewPlan('');
    queryClient.invalidateQueries({ queryKey: ['admin-users'] });
  };

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">User Management</h1>
      <Input placeholder="Cari user..." value={search} onChange={(e) => setSearch(e.target.value)} />
      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-3 px-3">User</th>
                  <th className="text-left py-3 px-3">Saldo</th>
                  <th className="text-left py-3 px-3">Plan</th>
                  <th className="text-left py-3 px-3">Status</th>
                  <th className="text-left py-3 px-3">Aksi</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((u: any) => (
                  <tr key={u.id} className="border-b last:border-0">
                    <td className="py-3 px-3">
                      <p className="font-medium">{u.name || '-'}</p>
                      <p className="text-xs text-muted-foreground">{u.email}</p>
                    </td>
                    <td className="py-3 px-3">Rp{u.balance.toLocaleString('id-ID')}</td>
                    <td className="py-3 px-3 capitalize">{u.plan}</td>
                    <td className="py-3 px-3">
                      <Badge variant="secondary" className={u.is_banned ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'}>
                        {u.is_banned ? 'Banned' : 'Active'}
                      </Badge>
                    </td>
                    <td className="py-3 px-3">
                      <div className="flex gap-1 flex-wrap">
                        <Button size="sm" variant="ghost" onClick={() => toggleBan(u.user_id, u.is_banned)}>
                          {u.is_banned ? <CheckCircle className="h-4 w-4 text-green-600" /> : <Ban className="h-4 w-4 text-red-600" />}
                        </Button>
                        <Button size="sm" variant="ghost" onClick={() => { setSelectedUser(u); setDialogType('balance'); }}>
                          <Wallet className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="ghost" onClick={() => { setSelectedUser(u); setDialogType('plan'); setNewPlan(u.plan); }}>
                          <Crown className="h-4 w-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      <Dialog open={dialogType === 'balance'} onOpenChange={() => setDialogType(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Ubah Saldo - {selectedUser?.name}</DialogTitle></DialogHeader>
          <p className="text-sm">Saldo saat ini: Rp{selectedUser?.balance.toLocaleString('id-ID')}</p>
          <div className="space-y-2">
            <Label>Nominal</Label>
            <Input type="number" value={balanceChange} onChange={(e) => setBalanceChange(e.target.value)} placeholder="Masukkan nominal" />
          </div>
          <div className="flex gap-2">
            <Button className="flex-1" onClick={() => handleBalanceChange(true)}>Tambah Saldo</Button>
            <Button variant="destructive" className="flex-1" onClick={() => handleBalanceChange(false)}>Kurangi Saldo</Button>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={dialogType === 'plan'} onOpenChange={() => setDialogType(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Ubah Plan - {selectedUser?.name}</DialogTitle></DialogHeader>
          <div className="space-y-2">
            <Label>Plan Baru</Label>
            <Select value={newPlan} onValueChange={setNewPlan}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="free">Free</SelectItem>
                <SelectItem value="basic">Basic</SelectItem>
                <SelectItem value="premium">Premium</SelectItem>
                <SelectItem value="vip">VIP</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Button className="w-full" onClick={handlePlanChange}>Simpan</Button>
        </DialogContent>
      </Dialog>
    </div>
  );
}
