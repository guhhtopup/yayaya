import { useState, useEffect } from 'react';
import { useNavigate, Outlet, Link, useLocation } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { LayoutDashboard, Users, Monitor, MessageSquare, Info, ArrowLeft, Menu, X } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';

const navItems = [
  { path: '/admin', icon: LayoutDashboard, label: 'Dashboard' },
  { path: '/admin/monitoring', icon: Monitor, label: 'Monitoring' },
  { path: '/admin/users', icon: Users, label: 'Users' },
  { path: '/admin/informasi', icon: Info, label: 'Informasi' },
  { path: '/admin/tickets', icon: MessageSquare, label: 'Tickets' },
];

export default function AdminLayout() {
  const navigate = useNavigate();
  const location = useLocation();
  const [verified, setVerified] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  useEffect(() => {
    const isAdmin = sessionStorage.getItem('kaze_admin');
    if (!isAdmin) navigate('/profil');
    else setVerified(true);
  }, []);

  if (!verified) return null;

  return (
    <div className="flex min-h-screen bg-background">
      {/* Mobile sidebar toggle */}
      <Button variant="ghost" size="icon" className="fixed top-3 left-3 z-50 lg:hidden" onClick={() => setSidebarOpen(!sidebarOpen)}>
        {sidebarOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
      </Button>

      {/* Sidebar */}
      <aside className={cn(
        'fixed inset-y-0 left-0 z-40 w-60 border-r bg-card transition-transform lg:static lg:translate-x-0',
        sidebarOpen ? 'translate-x-0' : '-translate-x-full'
      )}>
        <div className="p-4 border-b">
          <h2 className="text-lg font-bold text-primary">Kaze Admin</h2>
        </div>
        <nav className="p-2 space-y-1">
          {navItems.map((item) => (
            <Link key={item.path} to={item.path} onClick={() => setSidebarOpen(false)}
              className={cn('flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors',
                location.pathname === item.path ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:bg-accent'
              )}>
              <item.icon className="h-4 w-4" />
              {item.label}
            </Link>
          ))}
        </nav>
        <div className="absolute bottom-4 left-4">
          <Button variant="ghost" size="sm" onClick={() => { sessionStorage.removeItem('kaze_admin'); navigate('/profil'); }}>
            <ArrowLeft className="mr-2 h-4 w-4" /> Kembali
          </Button>
        </div>
      </aside>

      {/* Overlay */}
      {sidebarOpen && <div className="fixed inset-0 z-30 bg-black/50 lg:hidden" onClick={() => setSidebarOpen(false)} />}

      {/* Main content */}
      <main className="flex-1 p-4 lg:p-6 lg:ml-0 mt-12 lg:mt-0">
        <Outlet />
      </main>
    </div>
  );
}
