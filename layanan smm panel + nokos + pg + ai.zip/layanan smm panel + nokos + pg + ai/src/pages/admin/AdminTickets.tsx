import { useQuery, useQueryClient } from '@tanstack/react-query';
import { adminApi } from '@/lib/adminApi';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';

export default function AdminTickets() {
  const queryClient = useQueryClient();

  const { data: tickets } = useQuery({
    queryKey: ['admin-tickets'],
    queryFn: () => adminApi.getTickets(),
  });

  const closeTicket = async (id: string) => {
    await adminApi.updateTicket(id, { status: 'closed' });
    toast.success('Ticket ditutup');
    queryClient.invalidateQueries({ queryKey: ['admin-tickets'] });
  };

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">Tickets</h1>
      <div className="space-y-3">
        {tickets?.map((t: any) => (
          <Card key={t.id} className="border-l-4 border-l-primary">
            <CardContent className="p-4">
              <div className="flex justify-between items-start mb-2">
                <div>
                  <p className="font-semibold">{t.name}</p>
                  <p className="text-xs text-muted-foreground">{t.email}</p>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="secondary" className={t.status === 'open' ? 'bg-yellow-100 text-yellow-700' : 'bg-green-100 text-green-700'}>
                    {t.status}
                  </Badge>
                  {t.status === 'open' && (
                    <Button size="sm" variant="outline" onClick={() => closeTicket(t.id)}>Tutup</Button>
                  )}
                </div>
              </div>
              <div className="bg-muted rounded-lg p-3 mt-2">
                <p className="text-sm whitespace-pre-wrap">{t.message}</p>
              </div>
              <p className="text-xs text-muted-foreground mt-2">
                {new Date(t.created_at).toLocaleString('id-ID')}
              </p>
            </CardContent>
          </Card>
        ))}
        {(!tickets || tickets.length === 0) && <p className="text-center text-muted-foreground py-8">Belum ada ticket</p>}
      </div>
    </div>
  );
}
