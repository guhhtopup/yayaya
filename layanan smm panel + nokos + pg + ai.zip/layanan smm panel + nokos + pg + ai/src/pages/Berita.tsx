import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { ArrowLeft, Newspaper, ExternalLink } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function Berita() {
  const navigate = useNavigate();

  const { data: news, isLoading } = useQuery({
    queryKey: ['berita'],
    queryFn: async () => {
      const { data } = await supabase.functions.invoke('proxy-berita');
      return data?.data || data || [];
    },
  });

  return (
    <div className="mx-auto max-w-lg px-4 py-6 space-y-4">
      <button onClick={() => navigate(-1)} className="flex items-center gap-2 text-sm text-muted-foreground">
        <ArrowLeft className="h-4 w-4" /> Kembali
      </button>
      <h1 className="text-xl font-bold flex items-center gap-2"><Newspaper className="h-5 w-5 text-primary" /> Berita Terkini</h1>

      {isLoading ? (
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (<Skeleton key={i} className="h-28 w-full rounded-xl" />))}
        </div>
      ) : (
        <div className="space-y-3">
          {(news || []).map((item: any, i: number) => (
            <Card key={i} className="overflow-hidden hover:shadow-md transition-shadow">
              <CardContent className="p-0">
                <a href={item.link || item.url || '#'} target="_blank" rel="noopener noreferrer" className="flex gap-3 p-3">
                  {(item.image || item.thumbnail) && (
                    <img src={item.image || item.thumbnail} alt="" className="h-20 w-20 rounded-lg object-cover flex-shrink-0" />
                  )}
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium line-clamp-2">{item.title}</p>
                    <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{item.description || item.desc}</p>
                    <p className="text-xs text-primary mt-1 flex items-center gap-1"><ExternalLink className="h-3 w-3" /> Baca selengkapnya</p>
                  </div>
                </a>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
