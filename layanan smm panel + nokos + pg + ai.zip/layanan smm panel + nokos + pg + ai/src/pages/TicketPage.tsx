import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { ArrowLeft, Ticket, Send } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { Badge } from '@/components/ui/badge';

export default function TicketPage() {
  const { user, profile } = useAuth();
  const navigate = useNavigate();
  const [name, setName] = useState(profile?.name || '');
  const [email, setEmail] = useState(user?.email || '');
  const [message, setMessage] = useState('');
  const [sending, setSending] = useState(false);

  const { data: tickets, refetch } = useQuery({
    queryKey: ['my-tickets', user?.id],
    queryFn: async () => {
      const { data } = await supabase.from('tickets').select('*').eq('user_id', user!.id).order('created_at', { ascending: false });
      return data || [];
    },
    enabled: !!user,
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim() || !message.trim()) { toast.error('Lengkapi semua field'); return; }
    setSending(true);
    try {
      const { error } = await supabase.from('tickets').insert({ user_id: user!.id, name: name.trim(), email: email.trim(), message: message.trim() });
      if (error) throw error;
      toast.success('Ticket berhasil dikirim!');
      setMessage('');
      refetch();
    } catch (err: any) {
      toast.error(err.message || 'Gagal mengirim ticket');
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="mx-auto max-w-lg px-4 py-6 space-y-4">
      <button onClick={() => navigate(-1)} className="flex items-center gap-2 text-sm text-muted-foreground">
        <ArrowLeft className="h-4 w-4" /> Kembali
      </button>
      <h1 className="text-xl font-bold flex items-center gap-2"><Ticket className="h-5 w-5 text-primary" /> Ticket Support</h1>

      <Card>
        <CardHeader><CardTitle className="text-base">Buat Ticket Baru</CardTitle></CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-3">
            <div className="space-y-2">
              <Label>Nama</Label>
              <Input value={name} onChange={(e) => setName(e.target.value)} required />
            </div>
            <div className="space-y-2">
              <Label>Email</Label>
              <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
            </div>
            <div className="space-y-2">
              <Label>Pesan</Label>
              <Textarea value={message} onChange={(e) => setMessage(e.target.value)} placeholder="Jelaskan masalah Anda..." rows={4} required />
            </div>
            <Button type="submit" className="w-full" disabled={sending}>
              <Send className="mr-2 h-4 w-4" /> {sending ? 'Mengirim...' : 'Kirim Ticket'}
            </Button>
          </form>
        </CardContent>
      </Card>

      {tickets && tickets.length > 0 && (
        <div>
          <h2 className="text-base font-semibold mb-2">Riwayat Ticket</h2>
          <div className="space-y-2">
            {tickets.map((t) => (
              <Card key={t.id}>
                <CardContent className="p-3">
                  <div className="flex justify-between items-start">
                    <p className="text-sm line-clamp-2">{t.message}</p>
                    <Badge variant="secondary" className={t.status === 'open' ? 'bg-yellow-100 text-yellow-700' : 'bg-green-100 text-green-700'}>{t.status}</Badge>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">{new Date(t.created_at).toLocaleDateString('id-ID')}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
