import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { ArrowLeft, Tv, Search, ExternalLink } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function Anime() {
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [query, setQuery] = useState('');

  const { data: results, isLoading } = useQuery({
    queryKey: ['anime-search', query],
    queryFn: async () => {
      if (!query) return [];
      const { data } = await supabase.functions.invoke('proxy-anime', { body: { action: 'search', q: query } });
      return data?.data || data || [];
    },
    enabled: !!query,
  });

  return (
    <div className="mx-auto max-w-lg px-4 py-6 space-y-4">
      <button onClick={() => navigate(-1)} className="flex items-center gap-2 text-sm text-muted-foreground">
        <ArrowLeft className="h-4 w-4" /> Kembali
      </button>
      <h1 className="text-xl font-bold flex items-center gap-2"><Tv className="h-5 w-5 text-primary" /> Anime</h1>

      <div className="flex gap-2">
        <Input placeholder="Cari anime..." value={search} onChange={(e) => setSearch(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && setQuery(search)} />
        <Button onClick={() => setQuery(search)}><Search className="h-4 w-4" /></Button>
      </div>

      {isLoading ? (
        <div className="space-y-3">{[1, 2, 3].map((i) => (<Skeleton key={i} className="h-28 w-full rounded-xl" />))}</div>
      ) : (
        <div className="space-y-3">
          {(results || []).map((item: any, i: number) => (
            <Card key={i} className="overflow-hidden hover:shadow-md transition-shadow">
              <CardContent className="p-0">
                <a href={item.url || item.link || '#'} target="_blank" rel="noopener noreferrer" className="flex gap-3 p-3">
                  {(item.thumbnail || item.image) && (
                    <img src={item.thumbnail || item.image} alt="" className="h-24 w-16 rounded-lg object-cover flex-shrink-0" />
                  )}
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium line-clamp-2">{item.title}</p>
                    {item.genres && <p className="text-xs text-muted-foreground mt-1">{item.genres}</p>}
                    {item.status && <p className="text-xs text-muted-foreground">{item.status}</p>}
                    <p className="text-xs text-primary mt-1 flex items-center gap-1"><ExternalLink className="h-3 w-3" /> Detail</p>
                  </div>
                </a>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
