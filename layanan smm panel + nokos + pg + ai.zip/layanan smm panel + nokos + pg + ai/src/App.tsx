import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/contexts/AuthContext";
import AppLayout from "@/components/AppLayout";
import Index from "./pages/Index";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Deposit from "./pages/Deposit";
import SmmPanel from "./pages/SmmPanel";
import Nokos from "./pages/Nokos";
import Berita from "./pages/Berita";
import Anime from "./pages/Anime";
import History from "./pages/History";
import AiChat from "./pages/AiChat";
import Informasi from "./pages/Informasi";
import Profil from "./pages/Profil";
import TicketPage from "./pages/TicketPage";
import AdminLayout from "./pages/admin/AdminLayout";
import AdminDashboard from "./pages/admin/AdminDashboard";
import AdminMonitoring from "./pages/admin/AdminMonitoring";
import AdminUsers from "./pages/admin/AdminUsers";
import AdminInformasi from "./pages/admin/AdminInformasi";
import AdminTickets from "./pages/admin/AdminTickets";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AuthProvider>
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route element={<AppLayout />}>
              <Route path="/" element={<Index />} />
              <Route path="/deposit" element={<Deposit />} />
              <Route path="/smm" element={<SmmPanel />} />
              <Route path="/nokos" element={<Nokos />} />
              <Route path="/berita" element={<Berita />} />
              <Route path="/anime" element={<Anime />} />
              <Route path="/history" element={<History />} />
              <Route path="/ai" element={<AiChat />} />
              <Route path="/informasi" element={<Informasi />} />
              <Route path="/profil" element={<Profil />} />
              <Route path="/ticket" element={<TicketPage />} />
            </Route>
            <Route path="/admin" element={<AdminLayout />}>
              <Route index element={<AdminDashboard />} />
              <Route path="monitoring" element={<AdminMonitoring />} />
              <Route path="users" element={<AdminUsers />} />
              <Route path="informasi" element={<AdminInformasi />} />
              <Route path="tickets" element={<AdminTickets />} />
            </Route>
            <Route path="*" element={<NotFound />} />
          </Routes>
        </AuthProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
